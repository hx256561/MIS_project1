import java.util.ArrayList;
public class KeywordList {
	public ArrayList<Keyword> list=new ArrayList<Keyword>();
	
	public void addList(Keyword k) {
		list.add(k);
	}

}
